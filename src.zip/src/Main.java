import tr.controller.GirisController;
import tr.dao.KullaniciDAO;
import tr.view.GirisEkrani;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        // UI Thread güvenliği için
        SwingUtilities.invokeLater(() -> {
            try {
                // Sistem görünümünü kullan
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }

            // Giriş ekranını başlat
            GirisEkrani girisEkrani = new GirisEkrani();
            KullaniciDAO kullaniciDAO = new KullaniciDAO();
            new GirisController(girisEkrani, kullaniciDAO);
            
            girisEkrani.ekranGoster();
        });
    }
}
