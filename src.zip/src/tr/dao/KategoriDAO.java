package tr.dao;

import tr.model.Kategori;
import tr.util.VeritabaniBaglantisi;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class KategoriDAO {

    public List<Kategori> tumKategorileriGetir() {
        List<Kategori> kategoriler = new ArrayList<>();
        String sql = "SELECT * FROM kategoriler ORDER BY ad"; // Alfabetik sıralama eklendi
        
        try (Connection conn = VeritabaniBaglantisi.baglantiGetir();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                kategoriler.add(new Kategori(
                    rs.getInt("id"),
                    rs.getString("ad")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return kategoriler;
    }

    public void kategoriEkle(String ad) {
        String sql = "INSERT INTO kategoriler (ad) VALUES (?)";
        try (Connection conn = VeritabaniBaglantisi.baglantiGetir();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, ad);
            pstmt.executeUpdate();
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
