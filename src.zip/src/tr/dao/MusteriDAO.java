package tr.dao;

import tr.model.Musteri;
import tr.util.VeritabaniBaglantisi;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MusteriDAO {

    public List<Musteri> tumMusterileriGetir() {
        List<Musteri> musteriler = new ArrayList<>();
        String sql = "SELECT * FROM musteriler ORDER BY ad_soyad";
        
        try (Connection conn = VeritabaniBaglantisi.baglantiGetir();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                musteriler.add(new Musteri(
                    rs.getInt("id"),
                    rs.getString("ad_soyad"),
                    rs.getString("telefon"),
                    rs.getString("adres")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return musteriler;
    }

    // İsme göre müşteri ID'sini bulur, yoksa yeni oluşturup ID'sini döner
    public int musteriBulVeyaOlustur(String adSoyad) {
        String aramaSql = "SELECT id FROM musteriler WHERE ad_soyad = ?";
        String eklemeSql = "INSERT INTO musteriler (ad_soyad, telefon, adres) VALUES (?, '', '')"; // Telefon ve adres boş geçiliyor
        
        try (Connection conn = VeritabaniBaglantisi.baglantiGetir()) {
            // 1. Önce var mı diye bak
            try (PreparedStatement pstmt = conn.prepareStatement(aramaSql)) {
                pstmt.setString(1, adSoyad);
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        return rs.getInt("id");
                    }
                }
            }
            
            // 2. Yoksa ekle ve ID'yi al
            try (PreparedStatement pstmt = conn.prepareStatement(eklemeSql, Statement.RETURN_GENERATED_KEYS)) {
                pstmt.setString(1, adSoyad);
                pstmt.executeUpdate();
                
                try (ResultSet rs = pstmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        return rs.getInt(1);
                    }
                }
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1; // Hata durumu
    }
}
