package tr.view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.tree.DefaultMutableTreeNode;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;

public class AnaEkran extends JFrame {
    private JTabbedPane tabbedPane;
    
    // Üst Panel Bileşenleri
    private JLabel lblKullaniciBilgi;
    private JButton btnCikis;

    // Ürünler Bileşenleri
    private JTable tblUrunler;
    private DefaultTableModel urunTableModel;
    private JButton btnUrunEkle, btnUrunDuzenle, btnUrunSil, btnUrunYenile;
    private JTextField txtUrunAra;
    
    // Personel Bileşenleri
    private JTable tblPersonel;
    private DefaultTableModel personelTableModel;
    private JButton btnPersonelEkle, btnPersonelDuzenle, btnPersonelSil, btnPersonelYenile;

    // Talepler Bileşenleri
    private JTable tblTalepler;
    private DefaultTableModel talepTableModel;
    private JButton btnTalepEkle, btnTalepYenile;

    // Hareketler Bileşenleri
    private JTable tblHareketler;
    private DefaultTableModel hareketTableModel;
    private JButton btnHareketEkle, btnHareketYenile;

    // Kategori Ağacı Bileşenleri
    private JTree treeKategoriler;
    private DefaultMutableTreeNode rootNode;
    private JPopupMenu popupKategori; // Sağ tık menüsü
    private JMenuItem itemKategoriEkle; // Menü elemanı

    public AnaEkran() {
        setTitle("Stok Yönetim Sistemi - Profesyonel Sürüm");
        setSize(1200, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // --- ÜST PANEL ---
        JPanel pnlUst = new JPanel(new BorderLayout());
        pnlUst.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        pnlUst.setBackground(new Color(240, 240, 240));
        
        JLabel lblBaslik = new JLabel("STOK YÖNETİM SİSTEMİ");
        lblBaslik.setFont(new Font("Segoe UI", Font.BOLD, 16));
        pnlUst.add(lblBaslik, BorderLayout.WEST);
        
        // Sağ üst köşe (Kullanıcı Bilgisi + Çıkış Butonu)
        JPanel pnlSagUst = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        pnlSagUst.setOpaque(false);
        
        lblKullaniciBilgi = new JLabel("Kullanıcı: ");
        lblKullaniciBilgi.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblKullaniciBilgi.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 10));
        
        btnCikis = new JButton("Çıkış Yap");
        btnCikis.setBackground(new Color(220, 53, 69));
        btnCikis.setForeground(Color.WHITE);
        btnCikis.setFocusPainted(false);
        
        pnlSagUst.add(lblKullaniciBilgi);
        pnlSagUst.add(btnCikis);
        
        pnlUst.add(pnlSagUst, BorderLayout.EAST);
        add(pnlUst, BorderLayout.NORTH);

        // --- SOL PANEL (Kategoriler) ---
        rootNode = new DefaultMutableTreeNode("Kategoriler");
        treeKategoriler = new JTree(rootNode);
        JScrollPane scrollTree = new JScrollPane(treeKategoriler);
        scrollTree.setPreferredSize(new Dimension(220, 0));
        scrollTree.setBorder(BorderFactory.createTitledBorder("Kategori Ağacı"));
        add(scrollTree, BorderLayout.WEST);
        
        // Kategori Sağ Tık Menüsü
        popupKategori = new JPopupMenu();
        itemKategoriEkle = new JMenuItem("Yeni Kategori Ekle");
        popupKategori.add(itemKategoriEkle);
        
        // Ağaca menüyü bağla (Controller'da listener ile tetiklenecek ama burada da set edebiliriz)
        treeKategoriler.setComponentPopupMenu(popupKategori);

        // --- MERKEZ PANEL (TabbedPane) ---
        tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        // 1. Sekme: Ürünler
        tabbedPane.addTab("Ürün Yönetimi", createUrunPanel());

        // 2. Sekme: Personel Yönetimi
        tabbedPane.addTab("Personel Yönetimi", createPersonelPanel());

        // 3. Sekme: Talepler
        tabbedPane.addTab("Talepler", createTalepPanel());

        // 4. Sekme: Hareketler
        tabbedPane.addTab("Stok Hareketleri", createHareketPanel());

        add(tabbedPane, BorderLayout.CENTER);
    }

    private JPanel createUrunPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        
        JToolBar toolbar = new JToolBar();
        toolbar.setFloatable(false);
        
        btnUrunEkle = new JButton("Yeni Ürün");
        btnUrunDuzenle = new JButton("Düzenle");
        btnUrunSil = new JButton("Sil");
        btnUrunYenile = new JButton("Yenile");
        
        toolbar.add(btnUrunEkle);
        toolbar.add(btnUrunDuzenle);
        toolbar.add(btnUrunSil);
        toolbar.addSeparator();
        toolbar.add(btnUrunYenile);
        toolbar.add(Box.createHorizontalGlue());
        
        toolbar.add(new JLabel("Ara: "));
        txtUrunAra = new JTextField(15);
        txtUrunAra.setMaximumSize(new Dimension(200, 30));
        toolbar.add(txtUrunAra);
        
        panel.add(toolbar, BorderLayout.NORTH);

        String[] kolonlar = {"ID", "Ürün Adı", "Kategori", "Stok", "Fiyat (TL)"};
        urunTableModel = new DefaultTableModel(kolonlar, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tblUrunler = new JTable(urunTableModel);
        tblUrunler.setRowHeight(25);
        tblUrunler.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        panel.add(new JScrollPane(tblUrunler), BorderLayout.CENTER);
        
        return panel;
    }

    private JPanel createPersonelPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        
        JToolBar toolbar = new JToolBar();
        toolbar.setFloatable(false);
        
        btnPersonelEkle = new JButton("Yeni Personel");
        btnPersonelDuzenle = new JButton("Düzenle");
        btnPersonelSil = new JButton("Sil");
        btnPersonelYenile = new JButton("Yenile");
        
        toolbar.add(btnPersonelEkle);
        toolbar.add(btnPersonelDuzenle);
        toolbar.add(btnPersonelSil);
        toolbar.addSeparator();
        toolbar.add(btnPersonelYenile);
        
        panel.add(toolbar, BorderLayout.NORTH);

        String[] kolonlar = {"ID", "Ad", "Soyad", "Kullanıcı Adı", "Rol ID"};
        personelTableModel = new DefaultTableModel(kolonlar, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tblPersonel = new JTable(personelTableModel);
        tblPersonel.setRowHeight(25);
        tblPersonel.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        panel.add(new JScrollPane(tblPersonel), BorderLayout.CENTER);
        
        return panel;
    }

    private JPanel createTalepPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        
        JToolBar toolbar = new JToolBar();
        toolbar.setFloatable(false);
        
        btnTalepEkle = new JButton("Yeni Talep Oluştur");
        btnTalepYenile = new JButton("Yenile");
        
        toolbar.add(btnTalepEkle);
        toolbar.add(Box.createHorizontalGlue());
        toolbar.add(btnTalepYenile);
        
        panel.add(toolbar, BorderLayout.NORTH);

        String[] kolonlar = {"ID", "Kullanıcı", "Açıklama", "Durum"};
        talepTableModel = new DefaultTableModel(kolonlar, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tblTalepler = new JTable(talepTableModel);
        tblTalepler.setRowHeight(25);
        panel.add(new JScrollPane(tblTalepler), BorderLayout.CENTER);
        
        return panel;
    }

    private JPanel createHareketPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        
        JToolBar toolbar = new JToolBar();
        toolbar.setFloatable(false);
        
        btnHareketEkle = new JButton("Sipariş Oluştur");
        btnHareketYenile = new JButton("Yenile");
        
        toolbar.add(btnHareketEkle);
        toolbar.add(Box.createHorizontalGlue());
        toolbar.add(btnHareketYenile);
        panel.add(toolbar, BorderLayout.NORTH);

        String[] kolonlar = {"ID", "Ürün", "Müşteri", "Adet", "Tarih"};
        hareketTableModel = new DefaultTableModel(kolonlar, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tblHareketler = new JTable(hareketTableModel);
        tblHareketler.setRowHeight(25);
        panel.add(new JScrollPane(tblHareketler), BorderLayout.CENTER);
        
        return panel;
    }

    // Getter ve Setterlar
    public void setKullaniciBilgi(String bilgi) { lblKullaniciBilgi.setText(bilgi); }
    
    public DefaultTableModel getUrunTableModel() { return urunTableModel; }
    public JTable getTblUrunler() { return tblUrunler; }
    
    public DefaultTableModel getPersonelTableModel() { return personelTableModel; }
    public JTable getTblPersonel() { return tblPersonel; }
    
    public DefaultTableModel getTalepTableModel() { return talepTableModel; }
    public JTable getTblTalepler() { return tblTalepler; } // Getter eklendi
    
    public DefaultTableModel getHareketTableModel() { return hareketTableModel; }
    
    public DefaultMutableTreeNode getRootNode() { return rootNode; }
    public JTree getTreeKategoriler() { return treeKategoriler; }

    // Listener Ekleme Metotları
    public void addUrunEkleListener(ActionListener l) { btnUrunEkle.addActionListener(l); }
    public void addUrunDuzenleListener(ActionListener l) { btnUrunDuzenle.addActionListener(l); }
    public void addUrunSilListener(ActionListener l) { btnUrunSil.addActionListener(l); }
    public void addUrunYenileListener(ActionListener l) { btnUrunYenile.addActionListener(l); }
    
    public void addPersonelEkleListener(ActionListener l) { btnPersonelEkle.addActionListener(l); }
    public void addPersonelDuzenleListener(ActionListener l) { btnPersonelDuzenle.addActionListener(l); }
    public void addPersonelSilListener(ActionListener l) { btnPersonelSil.addActionListener(l); }
    public void addPersonelYenileListener(ActionListener l) { btnPersonelYenile.addActionListener(l); }
    
    public void addTalepEkleListener(ActionListener l) { btnTalepEkle.addActionListener(l); }
    public void addTalepYenileListener(ActionListener l) { btnTalepYenile.addActionListener(l); }
    
    public void addHareketEkleListener(ActionListener l) { btnHareketEkle.addActionListener(l); }
    public void addHareketYenileListener(ActionListener l) { btnHareketYenile.addActionListener(l); }
    
    public void addCikisListener(ActionListener l) { btnCikis.addActionListener(l); }
    
    // Kategori Ekleme Listener
    public void addKategoriEkleListener(ActionListener l) { itemKategoriEkle.addActionListener(l); }
    
    // Mouse Listener Ekleme
    public void addUrunTabloMouseListener(MouseListener l) { tblUrunler.addMouseListener(l); }
    public void addPersonelTabloMouseListener(MouseListener l) { tblPersonel.addMouseListener(l); }
    public void addTalepTabloMouseListener(MouseListener l) { tblTalepler.addMouseListener(l); } // Yeni Listener

    // YETKİLENDİRME METOTLARI
    public void setUrunYonetimiAktif(boolean aktif) {
        btnUrunEkle.setEnabled(aktif);
        btnUrunDuzenle.setEnabled(aktif);
        btnUrunSil.setEnabled(aktif);
        // Kategori ekleme yetkisi de buna bağlı olsun
        itemKategoriEkle.setEnabled(aktif);
    }
    
    public void setPersonelSekmesiGorunur(boolean gorunur) {
        if (!gorunur) {
            int index = tabbedPane.indexOfTab("Personel Yönetimi");
            if (index != -1) {
                tabbedPane.removeTabAt(index);
            }
        }
    }
}
