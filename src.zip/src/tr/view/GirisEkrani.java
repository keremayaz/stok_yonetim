package tr.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class GirisEkrani extends JFrame {
    private JTextField txtKullaniciAdi;
    private JPasswordField txtSifre;
    private JButton btnGiris;
    private JLabel lblDurum;

    public GirisEkrani() {
        setTitle("Stok Yönetim Sistemi - Giriş");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        JPanel panelMerkez = new JPanel(new GridLayout(3, 2, 10, 10));
        panelMerkez.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        panelMerkez.add(new JLabel("Kullanıcı Adı:"));
        txtKullaniciAdi = new JTextField();
        panelMerkez.add(txtKullaniciAdi);

        panelMerkez.add(new JLabel("Şifre:"));
        txtSifre = new JPasswordField();
        panelMerkez.add(txtSifre);

        btnGiris = new JButton("Giriş Yap");
        panelMerkez.add(new JLabel("")); // Boşluk
        panelMerkez.add(btnGiris);

        add(panelMerkez, BorderLayout.CENTER);

        lblDurum = new JLabel(" ");
        lblDurum.setHorizontalAlignment(SwingConstants.CENTER);
        lblDurum.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(lblDurum, BorderLayout.SOUTH);
    }

    public String getKullaniciAdi() {
        return txtKullaniciAdi.getText();
    }

    public String getSifre() {
        return new String(txtSifre.getPassword());
    }

    public void setGirisButtonListener(ActionListener listener) {
        btnGiris.addActionListener(listener);
    }

    public void setDurumMesaji(String mesaj) {
        lblDurum.setText(mesaj);
    }
    
    public void ekranGoster() {
        setVisible(true);
    }
    
    public void ekranKapat() {
        dispose();
    }
}
