package tr.view;

import tr.model.Urun;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class HareketDialog extends JDialog {
    private JComboBox<Urun> cmbUrun;
    private JTextField txtMusteriAd; // ComboBox yerine TextField
    private JSpinner spnAdet;
    private JButton btnKaydet;
    private JButton btnIptal;
    private boolean kaydetTiklandi = false;

    // Artık müşteri listesine ihtiyacımız yok
    public HareketDialog(Frame owner, List<Urun> urunler) {
        super(owner, "Yeni Sipariş Oluştur", true);
        setLayout(new BorderLayout());
        setSize(400, 250);
        setLocationRelativeTo(owner);

        // Form Paneli
        JPanel pnlForm = new JPanel(new GridBagLayout());
        pnlForm.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Ürün Seçimi
        gbc.gridx = 0; gbc.gridy = 0;
        pnlForm.add(new JLabel("Ürün Seçiniz:"), gbc);
        gbc.gridx = 1;
        cmbUrun = new JComboBox<>();
        for (Urun u : urunler) {
            cmbUrun.addItem(u);
        }
        pnlForm.add(cmbUrun, gbc);

        // Müşteri Adı (Elle Giriş)
        gbc.gridx = 0; gbc.gridy = 1;
        pnlForm.add(new JLabel("Müşteri Adı:"), gbc);
        gbc.gridx = 1;
        txtMusteriAd = new JTextField(20);
        pnlForm.add(txtMusteriAd, gbc);

        // Adet
        gbc.gridx = 0; gbc.gridy = 2;
        pnlForm.add(new JLabel("Adet:"), gbc);
        gbc.gridx = 1;
        spnAdet = new JSpinner(new SpinnerNumberModel(1, 1, 1000, 1));
        pnlForm.add(spnAdet, gbc);

        add(pnlForm, BorderLayout.CENTER);

        // Buton Paneli
        JPanel pnlButonlar = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnKaydet = new JButton("Siparişi Tamamla");
        btnIptal = new JButton("İptal");
        
        pnlButonlar.add(btnKaydet);
        pnlButonlar.add(btnIptal);
        add(pnlButonlar, BorderLayout.SOUTH);

        // Olaylar
        btnKaydet.addActionListener(e -> {
            if (txtMusteriAd.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Müşteri adı boş olamaz!", "Hata", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Urun seciliUrun = (Urun) cmbUrun.getSelectedItem();
            int adet = (int) spnAdet.getValue();
            
            if (seciliUrun.getStok() < adet) {
                JOptionPane.showMessageDialog(this, "Yetersiz Stok! Mevcut Stok: " + seciliUrun.getStok(), "Hata", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            kaydetTiklandi = true;
            setVisible(false);
        });

        btnIptal.addActionListener(e -> setVisible(false));
    }

    public boolean isKaydetTiklandi() {
        return kaydetTiklandi;
    }

    public Urun getSeciliUrun() {
        return (Urun) cmbUrun.getSelectedItem();
    }

    public String getMusteriAdi() {
        return txtMusteriAd.getText().trim();
    }

    public int getAdet() {
        return (int) spnAdet.getValue();
    }
}
