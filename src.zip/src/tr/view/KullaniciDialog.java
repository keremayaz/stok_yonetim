package tr.view;

import tr.model.Kullanici;
import tr.model.Rol;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class KullaniciDialog extends JDialog {
    private JTextField txtAd;
    private JTextField txtSoyad;
    private JTextField txtKullaniciAdi;
    private JPasswordField txtSifre;
    private JComboBox<Rol> cmbRol;
    private JButton btnKaydet;
    private JButton btnIptal;
    private boolean kaydetTiklandi = false;
    private Kullanici kullanici;

    public KullaniciDialog(Frame owner, List<Rol> roller, Kullanici duzenlenecekKullanici) {
        super(owner, duzenlenecekKullanici == null ? "Yeni Personel Ekle" : "Personel Düzenle", true);
        this.kullanici = duzenlenecekKullanici;
        
        setLayout(new BorderLayout());
        setSize(400, 350);
        setLocationRelativeTo(owner);

        // Form Paneli
        JPanel pnlForm = new JPanel(new GridBagLayout());
        pnlForm.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Ad
        gbc.gridx = 0; gbc.gridy = 0;
        pnlForm.add(new JLabel("Ad:"), gbc);
        gbc.gridx = 1;
        txtAd = new JTextField(20);
        pnlForm.add(txtAd, gbc);

        // Soyad
        gbc.gridx = 0; gbc.gridy = 1;
        pnlForm.add(new JLabel("Soyad:"), gbc);
        gbc.gridx = 1;
        txtSoyad = new JTextField(20);
        pnlForm.add(txtSoyad, gbc);

        // Kullanıcı Adı
        gbc.gridx = 0; gbc.gridy = 2;
        pnlForm.add(new JLabel("Kullanıcı Adı:"), gbc);
        gbc.gridx = 1;
        txtKullaniciAdi = new JTextField(20);
        pnlForm.add(txtKullaniciAdi, gbc);

        // Şifre
        gbc.gridx = 0; gbc.gridy = 3;
        pnlForm.add(new JLabel("Şifre:"), gbc);
        gbc.gridx = 1;
        txtSifre = new JPasswordField(20);
        pnlForm.add(txtSifre, gbc);

        // Rol
        gbc.gridx = 0; gbc.gridy = 4;
        pnlForm.add(new JLabel("Rol:"), gbc);
        gbc.gridx = 1;
        cmbRol = new JComboBox<>();
        for (Rol r : roller) {
            cmbRol.addItem(r);
        }
        pnlForm.add(cmbRol, gbc);

        add(pnlForm, BorderLayout.CENTER);

        // Buton Paneli
        JPanel pnlButonlar = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnKaydet = new JButton("Kaydet");
        btnIptal = new JButton("İptal");
        
        pnlButonlar.add(btnKaydet);
        pnlButonlar.add(btnIptal);
        add(pnlButonlar, BorderLayout.SOUTH);

        // Düzenleme modu ise doldur
        if (kullanici != null) {
            txtAd.setText(kullanici.getAd());
            txtSoyad.setText(kullanici.getSoyad());
            txtKullaniciAdi.setText(kullanici.getKullaniciAdi());
            txtSifre.setText(kullanici.getSifre());
            
            for (int i = 0; i < cmbRol.getItemCount(); i++) {
                if (cmbRol.getItemAt(i).getId() == kullanici.getRolId()) {
                    cmbRol.setSelectedIndex(i);
                    break;
                }
            }
        }

        // Olaylar
        btnKaydet.addActionListener(e -> {
            if (validasyon()) {
                kaydetTiklandi = true;
                setVisible(false);
            }
        });

        btnIptal.addActionListener(e -> setVisible(false));
    }

    private boolean validasyon() {
        if (txtAd.getText().trim().isEmpty() || txtKullaniciAdi.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ad ve Kullanıcı Adı boş olamaz!", "Hata", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    public boolean isKaydetTiklandi() {
        return kaydetTiklandi;
    }

    public Kullanici getKullanici() {
        if (kullanici == null) kullanici = new Kullanici();
        kullanici.setAd(txtAd.getText().trim());
        kullanici.setSoyad(txtSoyad.getText().trim());
        kullanici.setKullaniciAdi(txtKullaniciAdi.getText().trim());
        kullanici.setSifre(new String(txtSifre.getPassword()));
        kullanici.setRolId(((Rol) cmbRol.getSelectedItem()).getId());
        return kullanici;
    }
}
