package tr.view;

import tr.model.Talep;

import javax.swing.*;
import java.awt.*;

public class TalepDialog extends JDialog {
    private JTextArea txtAciklama;
    private JButton btnGonder;
    private JButton btnIptal;
    private boolean gonderTiklandi = false;
    private Talep talep;

    public TalepDialog(Frame owner) {
        super(owner, "Yeni Talep Oluştur", true);
        setLayout(new BorderLayout());
        setSize(400, 300);
        setLocationRelativeTo(owner);

        JPanel pnlMerkez = new JPanel(new BorderLayout());
        pnlMerkez.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        pnlMerkez.add(new JLabel("Talep Açıklaması:"), BorderLayout.NORTH);
        
        txtAciklama = new JTextArea();
        txtAciklama.setLineWrap(true);
        pnlMerkez.add(new JScrollPane(txtAciklama), BorderLayout.CENTER);
        
        add(pnlMerkez, BorderLayout.CENTER);

        JPanel pnlButonlar = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnGonder = new JButton("Gönder");
        btnIptal = new JButton("İptal");
        
        pnlButonlar.add(btnGonder);
        pnlButonlar.add(btnIptal);
        add(pnlButonlar, BorderLayout.SOUTH);

        btnGonder.addActionListener(e -> {
            if (txtAciklama.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Açıklama boş olamaz!", "Hata", JOptionPane.ERROR_MESSAGE);
                return;
            }
            gonderTiklandi = true;
            setVisible(false);
        });

        btnIptal.addActionListener(e -> setVisible(false));
    }

    public boolean isGonderTiklandi() {
        return gonderTiklandi;
    }

    public String getAciklama() {
        return txtAciklama.getText().trim();
    }
}
