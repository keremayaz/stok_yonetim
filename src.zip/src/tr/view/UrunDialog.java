package tr.view;

import tr.model.Kategori;
import tr.model.Urun;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class UrunDialog extends JDialog {
    private JTextField txtAd;
    private JComboBox<Kategori> cmbKategori;
    private JSpinner spnStok;
    private JTextField txtFiyat;
    private JButton btnKaydet;
    private JButton btnIptal;
    private boolean kaydetTiklandi = false;
    private Urun urun;

    public UrunDialog(Frame owner, List<Kategori> kategoriler, Urun duzenlenecekUrun) {
        super(owner, duzenlenecekUrun == null ? "Yeni Ürün Ekle" : "Ürün Düzenle", true);
        this.urun = duzenlenecekUrun;
        
        setLayout(new BorderLayout());
        setSize(400, 300);
        setLocationRelativeTo(owner);

        // Form Paneli
        JPanel pnlForm = new JPanel(new GridBagLayout());
        pnlForm.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Ad
        gbc.gridx = 0; gbc.gridy = 0;
        pnlForm.add(new JLabel("Ürün Adı:"), gbc);
        gbc.gridx = 1;
        txtAd = new JTextField(20);
        pnlForm.add(txtAd, gbc);

        // Kategori
        gbc.gridx = 0; gbc.gridy = 1;
        pnlForm.add(new JLabel("Kategori:"), gbc);
        gbc.gridx = 1;
        cmbKategori = new JComboBox<>();
        for (Kategori k : kategoriler) {
            cmbKategori.addItem(k);
        }
        pnlForm.add(cmbKategori, gbc);

        // Stok
        gbc.gridx = 0; gbc.gridy = 2;
        pnlForm.add(new JLabel("Stok Adedi:"), gbc);
        gbc.gridx = 1;
        spnStok = new JSpinner(new SpinnerNumberModel(0, 0, 10000, 1));
        pnlForm.add(spnStok, gbc);

        // Fiyat
        gbc.gridx = 0; gbc.gridy = 3;
        pnlForm.add(new JLabel("Fiyat (TL):"), gbc);
        gbc.gridx = 1;
        txtFiyat = new JTextField();
        pnlForm.add(txtFiyat, gbc);

        add(pnlForm, BorderLayout.CENTER);

        // Buton Paneli
        JPanel pnlButonlar = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnKaydet = new JButton("Kaydet");
        btnIptal = new JButton("İptal");
        
        pnlButonlar.add(btnKaydet);
        pnlButonlar.add(btnIptal);
        add(pnlButonlar, BorderLayout.SOUTH);

        // Eğer düzenleme modundaysak verileri doldur
        if (urun != null) {
            txtAd.setText(urun.getAd());
            spnStok.setValue(urun.getStok());
            txtFiyat.setText(String.valueOf(urun.getFiyat()));
            
            // Kategoriyi seç
            for (int i = 0; i < cmbKategori.getItemCount(); i++) {
                if (cmbKategori.getItemAt(i).getId() == urun.getKategoriId()) {
                    cmbKategori.setSelectedIndex(i);
                    break;
                }
            }
        }

        // Olaylar
        btnKaydet.addActionListener(e -> {
            if (validasyon()) {
                kaydetTiklandi = true;
                setVisible(false);
            }
        });

        btnIptal.addActionListener(e -> setVisible(false));
    }

    private boolean validasyon() {
        if (txtAd.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ürün adı boş olamaz!", "Hata", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        try {
            Double.parseDouble(txtFiyat.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Geçerli bir fiyat giriniz!", "Hata", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    public boolean isKaydetTiklandi() {
        return kaydetTiklandi;
    }

    public Urun getUrun() {
        if (urun == null) urun = new Urun();
        urun.setAd(txtAd.getText().trim());
        urun.setKategoriId(((Kategori) cmbKategori.getSelectedItem()).getId());
        urun.setStok((Integer) spnStok.getValue());
        urun.setFiyat(Double.parseDouble(txtFiyat.getText()));
        return urun;
    }
}
